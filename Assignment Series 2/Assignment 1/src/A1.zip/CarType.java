/**
 * @author Mehrdad Sabetzadeh, University of Ottawa
 */
public enum CarType {
	ELECTRIC, SMALL, REGULAR, LARGE, NA;
}